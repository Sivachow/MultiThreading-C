void Trans(int n);
void Sleep(int n);